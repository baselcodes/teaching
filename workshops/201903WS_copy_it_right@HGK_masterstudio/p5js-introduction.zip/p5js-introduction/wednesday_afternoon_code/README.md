# P5.js Starter Template
This is a "empty" starter template for you to go creative 🌈
