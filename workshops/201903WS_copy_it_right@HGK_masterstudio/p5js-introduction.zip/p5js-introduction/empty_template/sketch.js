// this executes once at the beginning
function setup() {
	createCanvas(windowWidth, windowHeight); // how big your sketch should be
}

// this executes 60 times a second
function draw() {
	background(255, 255, 0); // yellow background
}
